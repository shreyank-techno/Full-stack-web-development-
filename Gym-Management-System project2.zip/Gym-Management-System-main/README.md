# Gym-Management-System
Gyms are become the essential part of our lives, providing best exercise and  body building facilities to our society.

Therefore,  at the management end there are some necessary steps to maintain the records of every individual including trainer, trainees, and staff But maintaining the records on paper is very difficult So, it is necessary to have a computerized system that manages all these issues.

Thus working on the management system for Gym Industry are the basis of our project. We have developed an automated version of the manual system, named as Gym  Management System. This system also provides excellent security of data at to its user.
 

# Tools Used
![Screenshot 2023-04-05 111833](https://user-images.githubusercontent.com/100932107/230000972-0dbf94a5-4064-4180-9638-dd4835cc70ad.png)


Version Control System: Git

VCS Hosting: GitHub

Front-End: HTML, CSS and JS

Integrated Development Environment: VSCode.

# preview images

![Screenshot 2023-04-07 192609](https://user-images.githubusercontent.com/100932107/230634139-e4571207-15bb-4471-a3d6-0a73b9088e90.png)

![Screenshot 2023-04-07 192728](https://user-images.githubusercontent.com/100932107/230634273-3388d3fe-4a05-4f98-b291-7a5826404f60.png)


![Screenshot 2023-04-07 192756](https://user-images.githubusercontent.com/100932107/230634418-f039d09e-8554-4c40-806e-6e9775c48bf1.png)


![Screenshot 2023-04-07 195740](https://user-images.githubusercontent.com/100932107/230634570-15947590-5ed1-4890-838a-096a824f7b54.png)
 
![Screenshot 2023-04-07 193300](https://user-images.githubusercontent.com/100932107/230634509-5ed422b1-d9f1-4a61-b700-37ca0ad6c190.png)

# Login page looks like this

![Screenshot 2023-04-07 200232](https://user-images.githubusercontent.com/100932107/230634901-5fc89370-d110-41fc-ad22-5e1eaf7ab854.png)

![Screenshot 2023-04-07 200247](https://user-images.githubusercontent.com/100932107/230634923-7bdd81ec-6bf8-48bf-b85d-41b37534b540.png)

# Hi, I'm Kalyan! 👋
🚀 About Me

A full stack, Passionate , Young , Web developer. Breathing Teck & Computers, Never Stop learning and discovering stuff.

# Appendix
Don't mind to give the app a star ⭐ 

Thank you
